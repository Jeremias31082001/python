from django.shortcuts import render, get_object_or_404, redirect
from .models import Contacto
from forms import ContactoForm  # type: ignore

# Crear contacto
def crear_contacto(request):
    if request.method == 'POST':
        form = ContactoForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('listar_contactos')
    else:
        form = ContactoForm()
    return render(request, 'contactos/crear_contacto.html', {'form': form})

# Listar contactos
def listar_contactos(request):
    contactos = Contacto.objects.filter(eliminado=False)
    return render(request, 'contactos/listar_contactos.html', {'contactos': contactos})

# Editar contacto
def editar_contacto(request, contacto_id):
    contacto = get_object_or_404(Contacto, id=contacto_id)
    if request.method == 'POST':
        form = ContactoForm(request.POST, instance=contacto)
        if form.is_valid():
            form.save()
            return redirect('listar_contactos')
    else:
        form = ContactoForm(instance=contacto)
    return render(request, 'contactos/editar_contacto.html', {'form': form})

# Marcar como eliminado
def eliminar_contacto(request, contacto_id):
    contacto = get_object_or_404(Contacto, id=contacto_id)
    contacto.eliminado = True
    contacto.save()
    return redirect('listar_contactos')