from django.contrib import admin
from .models import Contacto

admin.site.register(Contacto)