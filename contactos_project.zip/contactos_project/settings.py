python manage.py makemigrations # type: ignore
python manage.py migrate # type: ignore
django-admin startproject contactos_project # type: ignore
cd contactos_project # type: ignore
python manage.py startapp contactos # type: ignore

INSTALLED_APPS = (
    'app',
    'app.views',
    #'bootstrap3_datetime',
    'djcelery',
    'kombu.transport.django',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.sites',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'django.contrib.admin',
    # Uncomment the next line to enable admin documentation:
    # 'django.contrib.admindocs',
)