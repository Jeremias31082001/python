from django.db import models

class Contacto(models.Model):
    nombre_completo = models.CharField(max_length=255)
    email = models.EmailField(unique=True)
    telefono = models.CharField(max_length=20)
    direccion = models.TextField()
    fecha_nacimiento = models.DateField()
    notas = models.TextField(blank=True, null=True)

    def __str__(self):
        return self.nombre_completo

from django.db import models

class Contacto(models.Model):
    nombre = models.CharField(max_length=100)
    correo_electronico = models.EmailField(unique=True)
    telefono = models.CharField(max_length=15, blank=True, null=True)
    direccion = models.TextField(blank=True, null=True)
    eliminado = models.BooleanField(default=False)

    def __str__(self):
        return self.nombre
    
from django.db import models
from django.db.models import Sum

import datetime


class Document(models.Model):
    title = models.CharField(max_length=200, default='')  # title of the post
    news = models.TextField(default='')  # body of the news
    image = models.FileField(upload_to='documents/%d/%m/%Y', default='')  # image file included in it
    link = models.CharField(max_length=500, default='')  # video file url if present
    pubdate = models.DateTimeField("Date", default=datetime.datetime.now())  # this is date of scrapping
    approvedflag = models.CharField(max_length=200, default='-1')  # approved or not -1 for not and 1 for approved
    publishedfrom = models.CharField(max_length=100, default='')  # this includes domain of page eg: twitter, greatandhra
    type = models.CharField(max_length=100, default='direct post')  # published author for future use
    approvedby = models.CharField(max_length=200, default='')   # user name of the approved person
    parse_objectid = models.CharField(max_length=200, default='')   # unique id response
    source = models.CharField(max_length=200, default='')   # page/post link


class fb_pages_sync(models.Model):
    pagename = models.CharField(max_length=500, default='')
    sync_flag = models.CharField(max_length=2, default='-1')
    status_run = models.CharField(max_length=2, default='-1')
    src_pages = models.CharField(max_length=2,
                                 default='f')  # flag bit to know about whether the pages are form facebook or twitter
    verfied = models.CharField(max_length=2, default='-1')


class Poll(models.Model):
    """A poll object for use in the application views and repository."""
    text = models.CharField(max_length=200)
    pub_date = models.DateTimeField('date published')

    def total_votes(self):
        """Calculates the total number of votes for this poll."""
        return self.choice_set.aggregate(Sum('votes'))['votes__sum']

    def __unicode__(self):
        """Returns a string representation of a poll."""
        return self.text


class Choice(models.Model):
    """A poll choice object for use in the application views and repository."""
    poll = models.ForeignKey(Poll)
    text = models.CharField(max_length=200)
    votes = models.IntegerField(default=0)

    def votes_percentage(self):
        """Calculates the percentage of votes for this choice."""
        total = self.poll.total_votes()
        return self.votes / float(total) * 100 if total > 0 else 0

    def __unicode__(self):
        """Returns a string representation of a choice."""
        return self.text